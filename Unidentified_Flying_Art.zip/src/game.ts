import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../7abe1ec8-bd5c-4ffe-b318-f17a330296bf/src/item"
import Script2 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script3 from "../1ab2733f-1782-4521-9eda-6aa8ad684277/src/item"
import Script4 from "../28352c3a-cc20-4ab4-b4b8-a4562a6b0d4d/src/item"
import Script5 from "../901e4555-8743-49bb-854c-c8b354a3e3e1/src/item"
import Script6 from "../6ff6b3aa-083a-4e8c-bdd8-b4d64e1f2db1/src/item"
import Script7 from "../b88efbbf-2a9a-47b4-86e1-e38ecc2b433b/src/item"
import Script8 from "../7d669c08-c354-45e4-b3a3-c915c8fd6b6e/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const verticalBlackPad = new Entity('verticalBlackPad')
engine.addEntity(verticalBlackPad)
verticalBlackPad.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
verticalBlackPad.addComponentOrReplace(transform2)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(8, 18.210384368896484, 0.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6793708801269531, 2.099456310272217, 0.126710444688797)
})
nftPictureFrame.addComponentOrReplace(transform3)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(8, 18.210384368896484, 15.5),
  rotation: new Quaternion(-5.772643037952989e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1.6793708801269531, 2.099456310272217, 0.126710444688797)
})
nftPictureFrame2.addComponentOrReplace(transform4)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(10.870126724243164, 18.21038246154785, 14.929097175598145),
  rotation: new Quaternion(-7.489263725781077e-15, 0.9807853102684021, -1.1691871293351142e-7, -0.19509033858776093),
  scale: new Vector3(1.6793732643127441, 2.099456310272217, 0.1267106533050537)
})
nftPictureFrame5.addComponentOrReplace(transform5)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(5.129874229431152, 18.210384368896484, 1.0709033012390137),
  rotation: new Quaternion(0, 0.19509033858776093, -2.3256577108554666e-8, 0.9807853102684021),
  scale: new Vector3(1.6793712377548218, 2.099456310272217, 0.12671047449111938)
})
nftPictureFrame6.addComponentOrReplace(transform6)

const nftPictureFrame9 = new Entity('nftPictureFrame9')
engine.addEntity(nftPictureFrame9)
nftPictureFrame9.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(13.303302764892578, 18.21038246154785, 13.303300857543945),
  rotation: new Quaternion(-9.18939098806023e-15, 0.9238795638084412, -1.1013501932666259e-7, -0.3826834559440613),
  scale: new Vector3(1.6793768405914307, 2.099456310272217, 0.1267107129096985)
})
nftPictureFrame9.addComponentOrReplace(transform7)

const nftPictureFrame10 = new Entity('nftPictureFrame10')
engine.addEntity(nftPictureFrame10)
nftPictureFrame10.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(2.6966991424560547, 18.210384368896484, 2.6966991424560547),
  rotation: new Quaternion(-2.220446049250313e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(1.6793709993362427, 2.099456310272217, 0.12671047449111938)
})
nftPictureFrame10.addComponentOrReplace(transform8)

const nftPictureFrame13 = new Entity('nftPictureFrame13')
engine.addEntity(nftPictureFrame13)
nftPictureFrame13.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(14.929098129272461, 18.21038246154785, 10.870125770568848),
  rotation: new Quaternion(-1.1761363333717603e-14, 0.8314695954322815, -9.911890685998515e-8, -0.5555702447891235),
  scale: new Vector3(1.6793733835220337, 2.099456310272217, 0.12671056389808655)
})
nftPictureFrame13.addComponentOrReplace(transform9)

const nftPictureFrame14 = new Entity('nftPictureFrame14')
engine.addEntity(nftPictureFrame14)
nftPictureFrame14.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(1.0709037780761719, 18.210384368896484, 5.129875183105469),
  rotation: new Quaternion(-1.1059513315930347e-15, 0.5555702447891235, -6.622912707143769e-8, 0.8314695954322815),
  scale: new Vector3(1.6793718338012695, 2.099456310272217, 0.1267104595899582)
})
nftPictureFrame14.addComponentOrReplace(transform10)

const nftPictureFrame17 = new Entity('nftPictureFrame17')
engine.addEntity(nftPictureFrame17)
nftPictureFrame17.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(15.500001907348633, 18.21038246154785, 7.999999046325684),
  rotation: new Quaternion(-1.607642953493655e-14, 0.7071068286895752, -8.42937097900176e-8, -0.7071068286895752),
  scale: new Vector3(1.6793936491012573, 2.099456310272217, 0.12671075761318207)
})
nftPictureFrame17.addComponentOrReplace(transform11)

const nftPictureFrame18 = new Entity('nftPictureFrame18')
engine.addEntity(nftPictureFrame18)
nftPictureFrame18.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(0.5000004768371582, 18.210384368896484, 8.000000953674316),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.6793878078460693, 2.099456310272217, 0.1267107129096985)
})
nftPictureFrame18.addComponentOrReplace(transform12)

const nftPictureFrame21 = new Entity('nftPictureFrame21')
engine.addEntity(nftPictureFrame21)
nftPictureFrame21.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(14.929099082946777, 18.21038055419922, 5.129873275756836),
  rotation: new Quaternion(-1.946613849930154e-14, 0.5555702447891235, -6.62291412822924e-8, -0.8314696550369263),
  scale: new Vector3(1.6793758869171143, 2.099456310272217, 0.1267107129096985)
})
nftPictureFrame21.addComponentOrReplace(transform13)

const nftPictureFrame22 = new Entity('nftPictureFrame22')
engine.addEntity(nftPictureFrame22)
nftPictureFrame22.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(1.0709037780761719, 18.210384368896484, 10.87012767791748),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.8314696550369263, -9.911889975455779e-8, 0.5555702447891235),
  scale: new Vector3(1.6793756484985352, 2.099456310272217, 0.12671078741550446)
})
nftPictureFrame22.addComponentOrReplace(transform14)

const nftPictureFrame25 = new Entity('nftPictureFrame25')
engine.addEntity(nftPictureFrame25)
nftPictureFrame25.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(13.303302764892578, 18.21038055419922, 2.69669771194458),
  rotation: new Quaternion(-2.237919153106043e-14, 0.3826834559440613, -4.561942645864292e-8, -0.9238795638084412),
  scale: new Vector3(1.6793744564056396, 2.099456310272217, 0.12671062350273132)
})
nftPictureFrame25.addComponentOrReplace(transform15)

const nftPictureFrame26 = new Entity('nftPictureFrame26')
engine.addEntity(nftPictureFrame26)
nftPictureFrame26.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(2.696700096130371, 18.210384368896484, 13.303302764892578),
  rotation: new Quaternion(-4.157467251052812e-15, 0.9238795638084412, -1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(1.6793794631958008, 2.099456310272217, 0.12671083211898804)
})
nftPictureFrame26.addComponentOrReplace(transform16)

const nftPictureFrame29 = new Entity('nftPictureFrame29')
engine.addEntity(nftPictureFrame29)
nftPictureFrame29.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(10.87012767791748, 18.21038055419922, 1.070901870727539),
  rotation: new Quaternion(-2.393412718178483e-14, 0.19509033858776093, -2.3256578884911505e-8, -0.9807853698730469),
  scale: new Vector3(1.6793742179870605, 2.099456310272217, 0.12671062350273132)
})
nftPictureFrame29.addComponentOrReplace(transform17)

const nftPictureFrame30 = new Entity('nftPictureFrame30')
engine.addEntity(nftPictureFrame30)
nftPictureFrame30.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(5.129876136779785, 18.210384368896484, 14.929099082946777),
  rotation: new Quaternion(-5.001426739258e-15, 0.9807853698730469, -1.1691871293351142e-7, 0.19509033858776093),
  scale: new Vector3(1.679381251335144, 2.099456310272217, 0.12671126425266266)
})
nftPictureFrame30.addComponentOrReplace(transform18)

const wallCorrugatedMetal3 = new Entity('wallCorrugatedMetal3')
engine.addEntity(wallCorrugatedMetal3)
wallCorrugatedMetal3.setParent(_scene)
const gltfShape = new GLTFShape("fc06dee32d081b553035a2f20f31ecca1177d483a2b196805a4f5c4fb3d2bedb/CorrugatedMetalWall.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
wallCorrugatedMetal3.addComponentOrReplace(gltfShape)
const transform19 = new Transform({
  position: new Vector3(14.871105194091797, 17.13419532775879, 4.302676200866699),
  rotation: new Quaternion(-0.3928474485874176, 0.3928474485874176, 0.5879377722740173, -0.5879378914833069),
  scale: new Vector3(1.3882898092269897, 0.42179664969444275, 0.09741251915693283)
})
wallCorrugatedMetal3.addComponentOrReplace(transform19)

const wallCorrugatedMetal = new Entity('wallCorrugatedMetal')
engine.addEntity(wallCorrugatedMetal)
wallCorrugatedMetal.setParent(_scene)
wallCorrugatedMetal.addComponentOrReplace(gltfShape)
const transform20 = new Transform({
  position: new Vector3(7.143883228302002, 17.13419532775879, 15.77977466583252),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(1.388304352760315, 0.4218018054962158, 0.09741246700286865)
})
wallCorrugatedMetal.addComponentOrReplace(transform20)

const wallCorrugatedMetal2 = new Entity('wallCorrugatedMetal2')
engine.addEntity(wallCorrugatedMetal2)
wallCorrugatedMetal2.setParent(_scene)
wallCorrugatedMetal2.addComponentOrReplace(gltfShape)
const transform21 = new Transform({
  position: new Vector3(7.143883228302002, 17.13419532775879, 0.37691688537597656),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(1.3882976770401, 0.42180097103118896, 0.09741246700286865)
})
wallCorrugatedMetal2.addComponentOrReplace(transform21)

const wallCorrugatedMetal4 = new Entity('wallCorrugatedMetal4')
engine.addEntity(wallCorrugatedMetal4)
wallCorrugatedMetal4.setParent(_scene)
wallCorrugatedMetal4.addComponentOrReplace(gltfShape)
const transform22 = new Transform({
  position: new Vector3(8.64388370513916, 17.13419532775879, 15.794133186340332),
  rotation: new Quaternion(-0.06930858641862869, 0.06930858641862869, -0.703701913356781, 0.703701913356781),
  scale: new Vector3(1.3883002996444702, 0.4217976927757263, 0.09741303324699402)
})
wallCorrugatedMetal4.addComponentOrReplace(transform22)

const wallCorrugatedMetal5 = new Entity('wallCorrugatedMetal5')
engine.addEntity(wallCorrugatedMetal5)
wallCorrugatedMetal5.setParent(_scene)
wallCorrugatedMetal5.addComponentOrReplace(gltfShape)
const transform23 = new Transform({
  position: new Vector3(5.643883228302002, 17.13419532775879, 0.6966204643249512),
  rotation: new Quaternion(-0.06930858641862869, 0.06930858641862869, -0.703701913356781, 0.703701913356781),
  scale: new Vector3(1.3882999420166016, 0.4217976927757263, 0.0974133089184761)
})
wallCorrugatedMetal5.addComponentOrReplace(transform23)

const wallCorrugatedMetal6 = new Entity('wallCorrugatedMetal6')
engine.addEntity(wallCorrugatedMetal6)
wallCorrugatedMetal6.setParent(_scene)
wallCorrugatedMetal6.addComponentOrReplace(gltfShape)
const transform24 = new Transform({
  position: new Vector3(4.143883228302002, 17.13419532775879, 1.3002147674560547),
  rotation: new Quaternion(-0.13794969022274017, 0.13794969022274017, -0.6935199499130249, 0.6935199499130249),
  scale: new Vector3(1.3882993459701538, 0.42179781198501587, 0.09741242229938507)
})
wallCorrugatedMetal6.addComponentOrReplace(transform24)

const wallCorrugatedMetal7 = new Entity('wallCorrugatedMetal7')
engine.addEntity(wallCorrugatedMetal7)
wallCorrugatedMetal7.setParent(_scene)
wallCorrugatedMetal7.addComponentOrReplace(gltfShape)
const transform25 = new Transform({
  position: new Vector3(10.14388370513916, 17.13419532775879, 15.51247501373291),
  rotation: new Quaternion(-0.13794969022274017, 0.13794969022274017, -0.6935199499130249, 0.6935199499130249),
  scale: new Vector3(1.3883017301559448, 0.42179781198501587, 0.09741242229938507)
})
wallCorrugatedMetal7.addComponentOrReplace(transform25)

const wallCorrugatedMetal8 = new Entity('wallCorrugatedMetal8')
engine.addEntity(wallCorrugatedMetal8)
wallCorrugatedMetal8.setParent(_scene)
wallCorrugatedMetal8.addComponentOrReplace(gltfShape)
const transform26 = new Transform({
  position: new Vector3(11.64388370513916, 17.13419532775879, 14.901866912841797),
  rotation: new Quaternion(-0.20526228845119476, 0.20526228845119476, -0.6766590476036072, 0.6766590476036072),
  scale: new Vector3(1.388301134109497, 0.42180219292640686, 0.09741246700286865)
})
wallCorrugatedMetal8.addComponentOrReplace(transform26)

const wallCorrugatedMetal9 = new Entity('wallCorrugatedMetal9')
engine.addEntity(wallCorrugatedMetal9)
wallCorrugatedMetal9.setParent(_scene)
wallCorrugatedMetal9.addComponentOrReplace(gltfShape)
const transform27 = new Transform({
  position: new Vector3(2.974832534790039, 17.13419532775879, 2.09759521484375),
  rotation: new Quaternion(-0.20526228845119476, 0.20526228845119476, -0.6766590476036072, 0.6766590476036072),
  scale: new Vector3(1.3883030414581299, 0.42180219292640686, 0.09741246700286865)
})
wallCorrugatedMetal9.addComponentOrReplace(transform27)

const wallCorrugatedMetal10 = new Entity('wallCorrugatedMetal10')
engine.addEntity(wallCorrugatedMetal10)
wallCorrugatedMetal10.setParent(_scene)
wallCorrugatedMetal10.addComponentOrReplace(gltfShape)
const transform28 = new Transform({
  position: new Vector3(1.904008388519287, 17.13419532775879, 3.191666603088379),
  rotation: new Quaternion(-0.27059805393218994, 0.27059805393218994, -0.653281569480896, 0.6532814502716064),
  scale: new Vector3(1.3883029222488403, 0.4217976927757263, 0.09741248935461044)
})
wallCorrugatedMetal10.addComponentOrReplace(transform28)

const wallCorrugatedMetal11 = new Entity('wallCorrugatedMetal11')
engine.addEntity(wallCorrugatedMetal11)
wallCorrugatedMetal11.setParent(_scene)
wallCorrugatedMetal11.addComponentOrReplace(gltfShape)
const transform29 = new Transform({
  position: new Vector3(13.000425338745117, 17.13419532775879, 14.017102241516113),
  rotation: new Quaternion(-0.27059805393218994, 0.27059805393218994, -0.653281569480896, 0.6532814502716064),
  scale: new Vector3(1.388303279876709, 0.4217974841594696, 0.09741248935461044)
})
wallCorrugatedMetal11.addComponentOrReplace(transform29)

const wallCorrugatedMetal12 = new Entity('wallCorrugatedMetal12')
engine.addEntity(wallCorrugatedMetal12)
wallCorrugatedMetal12.setParent(_scene)
wallCorrugatedMetal12.addComponentOrReplace(gltfShape)
const transform30 = new Transform({
  position: new Vector3(14.061976432800293, 17.13419532775879, 12.986556053161621),
  rotation: new Quaternion(0.3333278000354767, -0.3333278000354767, 0.6236125826835632, -0.6236124634742737),
  scale: new Vector3(1.388289451599121, 0.4217965006828308, 0.09741295874118805)
})
wallCorrugatedMetal12.addComponentOrReplace(transform30)

const wallCorrugatedMetal13 = new Entity('wallCorrugatedMetal13')
engine.addEntity(wallCorrugatedMetal13)
wallCorrugatedMetal13.setParent(_scene)
wallCorrugatedMetal13.addComponentOrReplace(gltfShape)
const transform31 = new Transform({
  position: new Vector3(1.1438837051391602, 17.13419532775879, 4.375225067138672),
  rotation: new Quaternion(0.3333278000354767, -0.3333278000354767, 0.6236125826835632, -0.6236124634742737),
  scale: new Vector3(1.388289451599121, 0.4217965006828308, 0.09741295874118805)
})
wallCorrugatedMetal13.addComponentOrReplace(transform31)

const wallCorrugatedMetal14 = new Entity('wallCorrugatedMetal14')
engine.addEntity(wallCorrugatedMetal14)
wallCorrugatedMetal14.setParent(_scene)
wallCorrugatedMetal14.addComponentOrReplace(gltfShape)
const transform32 = new Transform({
  position: new Vector3(0.5502991676330566, 17.13419532775879, 5.837533473968506),
  rotation: new Quaternion(0.3928475081920624, -0.3928475081920624, 0.5879378914833069, -0.5879377722740173),
  scale: new Vector3(1.3883012533187866, 0.4217977523803711, 0.09741252660751343)
})
wallCorrugatedMetal14.addComponentOrReplace(transform32)

const wallCorrugatedMetal15 = new Entity('wallCorrugatedMetal15')
engine.addEntity(wallCorrugatedMetal15)
wallCorrugatedMetal15.setParent(_scene)
wallCorrugatedMetal15.addComponentOrReplace(gltfShape)
const transform33 = new Transform({
  position: new Vector3(14.878572463989258, 17.13419532775879, 11.811707496643066),
  rotation: new Quaternion(0.3928475081920624, -0.3928475081920624, 0.5879378914833069, -0.5879377722740173),
  scale: new Vector3(1.3883051872253418, 0.4217985272407532, 0.0974125862121582)
})
wallCorrugatedMetal15.addComponentOrReplace(transform33)

const wallCorrugatedMetal16 = new Entity('wallCorrugatedMetal16')
engine.addEntity(wallCorrugatedMetal16)
wallCorrugatedMetal16.setParent(_scene)
wallCorrugatedMetal16.addComponentOrReplace(gltfShape)
const transform34 = new Transform({
  position: new Vector3(8.673666000366211, 17.13419532775879, 0.35582780838012695),
  rotation: new Quaternion(0.06930858641862869, -0.06930858641862869, -0.703701913356781, 0.703701913356781),
  scale: new Vector3(1.3882999420166016, 0.4217979311943054, 0.09741322696208954)
})
wallCorrugatedMetal16.addComponentOrReplace(transform34)

const wallCorrugatedMetal17 = new Entity('wallCorrugatedMetal17')
engine.addEntity(wallCorrugatedMetal17)
wallCorrugatedMetal17.setParent(_scene)
wallCorrugatedMetal17.addComponentOrReplace(gltfShape)
const transform35 = new Transform({
  position: new Vector3(5.643883228302002, 17.13419532775879, 15.47224235534668),
  rotation: new Quaternion(0.06930858641862869, -0.06930858641862869, -0.703701913356781, 0.703701913356781),
  scale: new Vector3(1.3883041143417358, 0.42179757356643677, 0.09741348773241043)
})
wallCorrugatedMetal17.addComponentOrReplace(transform35)

const wallCorrugatedMetal18 = new Entity('wallCorrugatedMetal18')
engine.addEntity(wallCorrugatedMetal18)
wallCorrugatedMetal18.setParent(_scene)
wallCorrugatedMetal18.addComponentOrReplace(gltfShape)
const transform36 = new Transform({
  position: new Vector3(10.201944351196289, 17.13419532775879, 0.627690315246582),
  rotation: new Quaternion(0.13794969022274017, -0.13794969022274017, -0.6935199499130249, 0.6935199499130249),
  scale: new Vector3(1.3882997035980225, 0.4217982292175293, 0.09741242229938507)
})
wallCorrugatedMetal18.addComponentOrReplace(transform36)

const wallCorrugatedMetal19 = new Entity('wallCorrugatedMetal19')
engine.addEntity(wallCorrugatedMetal19)
wallCorrugatedMetal19.setParent(_scene)
wallCorrugatedMetal19.addComponentOrReplace(gltfShape)
const transform37 = new Transform({
  position: new Vector3(4.244544982910156, 17.13419532775879, 14.874157905578613),
  rotation: new Quaternion(0.13794969022274017, -0.13794969022274017, -0.6935199499130249, 0.6935199499130249),
  scale: new Vector3(1.3883044719696045, 0.42179781198501587, 0.09741242229938507)
})
wallCorrugatedMetal19.addComponentOrReplace(transform37)

const wallCorrugatedMetal20 = new Entity('wallCorrugatedMetal20')
engine.addEntity(wallCorrugatedMetal20)
wallCorrugatedMetal20.setParent(_scene)
wallCorrugatedMetal20.addComponentOrReplace(gltfShape)
const transform38 = new Transform({
  position: new Vector3(3.019864082336426, 17.13419532775879, 14.041389465332031),
  rotation: new Quaternion(0.20526228845119476, -0.20526228845119476, -0.6766590476036072, 0.6766590476036072),
  scale: new Vector3(1.3883047103881836, 0.4218031167984009, 0.09741246700286865)
})
wallCorrugatedMetal20.addComponentOrReplace(transform38)

const wallCorrugatedMetal21 = new Entity('wallCorrugatedMetal21')
engine.addEntity(wallCorrugatedMetal21)
wallCorrugatedMetal21.setParent(_scene)
wallCorrugatedMetal21.addComponentOrReplace(gltfShape)
const transform39 = new Transform({
  position: new Vector3(11.533102989196777, 17.13419532775879, 1.1359338760375977),
  rotation: new Quaternion(0.20526228845119476, -0.20526228845119476, -0.6766590476036072, 0.6766590476036072),
  scale: new Vector3(1.3882979154586792, 0.4218015968799591, 0.09741246700286865)
})
wallCorrugatedMetal21.addComponentOrReplace(transform39)

const wallCorrugatedMetal22 = new Entity('wallCorrugatedMetal22')
engine.addEntity(wallCorrugatedMetal22)
wallCorrugatedMetal22.setParent(_scene)
wallCorrugatedMetal22.addComponentOrReplace(gltfShape)
const transform40 = new Transform({
  position: new Vector3(1.9557180404663086, 17.13419532775879, 12.986556053161621),
  rotation: new Quaternion(0.27059805393218994, -0.27059805393218994, -0.6532814502716064, 0.653281569480896),
  scale: new Vector3(1.388304352760315, 0.42179739475250244, 0.09741248935461044)
})
wallCorrugatedMetal22.addComponentOrReplace(transform40)

const wallCorrugatedMetal23 = new Entity('wallCorrugatedMetal23')
engine.addEntity(wallCorrugatedMetal23)
wallCorrugatedMetal23.setParent(_scene)
wallCorrugatedMetal23.addComponentOrReplace(gltfShape)
const transform41 = new Transform({
  position: new Vector3(12.804031372070312, 17.13419532775879, 1.9865550994873047),
  rotation: new Quaternion(0.27059805393218994, -0.27059805393218994, -0.6532814502716064, 0.653281569480896),
  scale: new Vector3(1.3883012533187866, 0.4217973053455353, 0.09741248935461044)
})
wallCorrugatedMetal23.addComponentOrReplace(transform41)

const wallCorrugatedMetal24 = new Entity('wallCorrugatedMetal24')
engine.addEntity(wallCorrugatedMetal24)
wallCorrugatedMetal24.setParent(_scene)
wallCorrugatedMetal24.addComponentOrReplace(gltfShape)
const transform42 = new Transform({
  position: new Vector3(15.794102668762207, 17.13419532775879, 8.815549850463867),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(1.388289451599121, 0.421796590089798, 0.09741250425577164)
})
wallCorrugatedMetal24.addComponentOrReplace(transform42)

const wallCorrugatedMetal25 = new Entity('wallCorrugatedMetal25')
engine.addEntity(wallCorrugatedMetal25)
wallCorrugatedMetal25.setParent(_scene)
wallCorrugatedMetal25.addComponentOrReplace(gltfShape)
const transform43 = new Transform({
  position: new Vector3(0.31200742721557617, 17.13419532775879, 8.823440551757812),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(1.388289451599121, 0.421796590089798, 0.09741250425577164)
})
wallCorrugatedMetal25.addComponentOrReplace(transform43)

const wallCorrugatedMetal26 = new Entity('wallCorrugatedMetal26')
engine.addEntity(wallCorrugatedMetal26)
wallCorrugatedMetal26.setParent(_scene)
wallCorrugatedMetal26.addComponentOrReplace(gltfShape)
const transform44 = new Transform({
  position: new Vector3(0.29785966873168945, 17.13419532775879, 7.250236511230469),
  rotation: new Quaternion(-0.44858381152153015, 0.44858381152153015, -0.5466009974479675, 0.546600878238678),
  scale: new Vector3(1.3882893323898315, 0.42179757356643677, 0.09741263836622238)
})
wallCorrugatedMetal26.addComponentOrReplace(transform44)

const wallCorrugatedMetal27 = new Entity('wallCorrugatedMetal27')
engine.addEntity(wallCorrugatedMetal27)
wallCorrugatedMetal27.setParent(_scene)
wallCorrugatedMetal27.addComponentOrReplace(gltfShape)
const transform45 = new Transform({
  position: new Vector3(15.478619575500488, 17.13419532775879, 10.320555686950684),
  rotation: new Quaternion(-0.44858381152153015, 0.44858381152153015, -0.5466009974479675, 0.546600878238678),
  scale: new Vector3(1.3882893323898315, 0.4217974543571472, 0.09741263836622238)
})
wallCorrugatedMetal27.addComponentOrReplace(transform45)

const wallCorrugatedMetal28 = new Entity('wallCorrugatedMetal28')
engine.addEntity(wallCorrugatedMetal28)
wallCorrugatedMetal28.setParent(_scene)
wallCorrugatedMetal28.addComponentOrReplace(gltfShape)
const transform46 = new Transform({
  position: new Vector3(0.27516698837280273, 17.13419532775879, 8.762130737304688),
  rotation: new Quaternion(0.44858378171920776, -0.44858378171920776, -0.546600878238678, 0.5466009974479675),
  scale: new Vector3(1.388289451599121, 0.4217990040779114, 0.09741321206092834)
})
wallCorrugatedMetal28.addComponentOrReplace(transform46)

const wallCorrugatedMetal29 = new Entity('wallCorrugatedMetal29')
engine.addEntity(wallCorrugatedMetal29)
wallCorrugatedMetal29.setParent(_scene)
wallCorrugatedMetal29.addComponentOrReplace(gltfShape)
const transform47 = new Transform({
  position: new Vector3(15.436899185180664, 17.13419532775879, 5.621065616607666),
  rotation: new Quaternion(0.44858378171920776, -0.44858378171920776, -0.546600878238678, 0.5466009974479675),
  scale: new Vector3(1.388289451599121, 0.4218001961708069, 0.09741349518299103)
})
wallCorrugatedMetal29.addComponentOrReplace(transform47)

const wallCorrugatedMetal30 = new Entity('wallCorrugatedMetal30')
engine.addEntity(wallCorrugatedMetal30)
wallCorrugatedMetal30.setParent(_scene)
wallCorrugatedMetal30.addComponentOrReplace(gltfShape)
const transform48 = new Transform({
  position: new Vector3(0.5505709648132324, 17.13419532775879, 10.240981101989746),
  rotation: new Quaternion(-0.3928474485874176, 0.3928474485874176, 0.5879377722740173, -0.5879378914833069),
  scale: new Vector3(1.3882898092269897, 0.42179664969444275, 0.09741251915693283)
})
wallCorrugatedMetal30.addComponentOrReplace(transform48)

const wallCorrugatedMetal31 = new Entity('wallCorrugatedMetal31')
engine.addEntity(wallCorrugatedMetal31)
wallCorrugatedMetal31.setParent(_scene)
wallCorrugatedMetal31.addComponentOrReplace(gltfShape)
const transform49 = new Transform({
  position: new Vector3(13.90109634399414, 17.13419532775879, 3.0429983139038086),
  rotation: new Quaternion(-0.3135015368461609, 0.3135015070438385, 0.6338112950325012, -0.6338114142417908),
  scale: new Vector3(1.3882898092269897, 0.42179667949676514, 0.09741252660751343)
})
wallCorrugatedMetal31.addComponentOrReplace(transform49)

const wallCorrugatedMetal32 = new Entity('wallCorrugatedMetal32')
engine.addEntity(wallCorrugatedMetal32)
wallCorrugatedMetal32.setParent(_scene)
wallCorrugatedMetal32.addComponentOrReplace(gltfShape)
const transform50 = new Transform({
  position: new Vector3(1.096334457397461, 17.13419532775879, 11.636837005615234),
  rotation: new Quaternion(-0.33655205368995667, 0.3365519940853119, 0.6218783259391785, -0.621878445148468),
  scale: new Vector3(1.3882920742034912, 0.42179733514785767, 0.09741254150867462)
})
wallCorrugatedMetal32.addComponentOrReplace(transform50)

const wallPlainGlass = new Entity('wallPlainGlass')
engine.addEntity(wallPlainGlass)
wallPlainGlass.setParent(_scene)
const transform51 = new Transform({
  position: new Vector3(13.565771102905273, 17.18914222717285, 2.299891471862793),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(5.7250657081604, 2.9038641452789307, 0.2081255465745926)
})
wallPlainGlass.addComponentOrReplace(transform51)
const gltfShape2 = new GLTFShape("ceed966710028a407635a309e91f31236a72714a515035e8330211b84c9b8445/PlainGlassWall.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
wallPlainGlass.addComponentOrReplace(gltfShape2)

const wallPlainGlass2 = new Entity('wallPlainGlass2')
engine.addEntity(wallPlainGlass2)
wallPlainGlass2.setParent(_scene)
wallPlainGlass2.addComponentOrReplace(gltfShape2)
const transform52 = new Transform({
  position: new Vector3(12.914426803588867, 17.18914222717285, 2.299891471862793),
  rotation: new Quaternion(-0.7071068286895752, -1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.900379657745361, 0.17050699889659882, -0.20812581479549408)
})
wallPlainGlass2.addComponentOrReplace(transform52)

const wallPlainGlass3 = new Entity('wallPlainGlass3')
engine.addEntity(wallPlainGlass3)
wallPlainGlass3.setParent(_scene)
wallPlainGlass3.addComponentOrReplace(gltfShape2)
const transform53 = new Transform({
  position: new Vector3(10.984317779541016, 17.18914222717285, 14.59882640838623),
  rotation: new Quaternion(-0.7071068286895752, -1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.978663682937622, 0.1705070436000824, -0.20812639594078064)
})
wallPlainGlass3.addComponentOrReplace(transform53)

const wallPlainGlass4 = new Entity('wallPlainGlass4')
engine.addEntity(wallPlainGlass4)
wallPlainGlass4.setParent(_scene)
wallPlainGlass4.addComponentOrReplace(gltfShape2)
const transform54 = new Transform({
  position: new Vector3(14.245421409606934, 17.18914222717285, 3.1846790313720703),
  rotation: new Quaternion(-0.5000000596046448, 0.5000000596046448, 0.49999988079071045, 0.5),
  scale: new Vector3(4.900381088256836, 0.17050717771053314, -0.2081257849931717)
})
wallPlainGlass4.addComponentOrReplace(transform54)

const wallPlainGlass5 = new Entity('wallPlainGlass5')
engine.addEntity(wallPlainGlass5)
wallPlainGlass5.setParent(_scene)
wallPlainGlass5.addComponentOrReplace(gltfShape2)
const transform55 = new Transform({
  position: new Vector3(2.119365692138672, 17.18914222717285, 3.1846790313720703),
  rotation: new Quaternion(-0.5000000596046448, 0.5000000596046448, 0.49999988079071045, 0.5),
  scale: new Vector3(4.900381088256836, 0.17050717771053314, -0.2081257849931717)
})
wallPlainGlass5.addComponentOrReplace(transform55)

const triggerArea = new Entity('triggerArea')
engine.addEntity(triggerArea)
triggerArea.setParent(_scene)
const transform56 = new Transform({
  position: new Vector3(8.000000953674316, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 17.54812240600586, 1)
})
triggerArea.addComponentOrReplace(transform56)

const wallCorrugatedMetal33 = new Entity('wallCorrugatedMetal33')
engine.addEntity(wallCorrugatedMetal33)
wallCorrugatedMetal33.setParent(_scene)
const transform57 = new Transform({
  position: new Vector3(14.106468200683594, 17.109619140625, 3.5),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.195091247558594, 1.0000035762786865, 0.20792178809642792)
})
wallCorrugatedMetal33.addComponentOrReplace(transform57)
wallCorrugatedMetal33.addComponentOrReplace(gltfShape)

const wallCorrugatedMetal34 = new Entity('wallCorrugatedMetal34')
engine.addEntity(wallCorrugatedMetal34)
wallCorrugatedMetal34.setParent(_scene)
wallCorrugatedMetal34.addComponentOrReplace(gltfShape)
const transform58 = new Transform({
  position: new Vector3(14.106468200683594, 17.109619140625, 8.502531051635742),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.195091247558594, 1.000004529953003, 0.2079222947359085)
})
wallCorrugatedMetal34.addComponentOrReplace(transform58)

const wallCorrugatedMetal35 = new Entity('wallCorrugatedMetal35')
engine.addEntity(wallCorrugatedMetal35)
wallCorrugatedMetal35.setParent(_scene)
wallCorrugatedMetal35.addComponentOrReplace(gltfShape)
const transform59 = new Transform({
  position: new Vector3(10.977273941040039, 17.109619140625, 13.002531051635742),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.0975451469421387, 0.5000025629997253, 0.20792248845100403)
})
wallCorrugatedMetal35.addComponentOrReplace(transform59)

const wallCorrugatedMetal36 = new Entity('wallCorrugatedMetal36')
engine.addEntity(wallCorrugatedMetal36)
wallCorrugatedMetal36.setParent(_scene)
wallCorrugatedMetal36.addComponentOrReplace(gltfShape)
const transform60 = new Transform({
  position: new Vector3(10.977273941040039, 17.109619140625, 1.0025310516357422),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.0975451469421387, 0.5000026822090149, 0.2079225778579712)
})
wallCorrugatedMetal36.addComponentOrReplace(transform60)

const wallCorrugatedMetal37 = new Entity('wallCorrugatedMetal37')
engine.addEntity(wallCorrugatedMetal37)
wallCorrugatedMetal37.setParent(_scene)
wallCorrugatedMetal37.addComponentOrReplace(gltfShape)
const transform61 = new Transform({
  position: new Vector3(15.309713363647461, 17.109619140625, 10.443421363830566),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(2.3679471015930176, 0.2129322737455368, 0.20792269706726074)
})
wallCorrugatedMetal37.addComponentOrReplace(transform61)

const wallCorrugatedMetal38 = new Entity('wallCorrugatedMetal38')
engine.addEntity(wallCorrugatedMetal38)
wallCorrugatedMetal38.setParent(_scene)
wallCorrugatedMetal38.addComponentOrReplace(gltfShape)
const transform62 = new Transform({
  position: new Vector3(1.4154601097106934, 17.109619140625, 10.443421363830566),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(2.3679471015930176, 0.16973888874053955, 0.20792269706726074)
})
wallCorrugatedMetal38.addComponentOrReplace(transform62)

const dclLogo = new Entity('dclLogo')
engine.addEntity(dclLogo)
dclLogo.setParent(_scene)
const transform63 = new Transform({
  position: new Vector3(15.498507499694824, 19.990657806396484, 8.100235939025879),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.19281332194805145, 9.195158004760742, 9.195114135742188)
})
dclLogo.addComponentOrReplace(transform63)
const gltfShape3 = new GLTFShape("096328824448d45480a4e7d7870cf89bb71a3b64c9b253739ebd02ad5607b61f/DecentralandLogo_01/DecentralandLogo_01.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
dclLogo.addComponentOrReplace(gltfShape3)

const signpostTree2 = new Entity('signpostTree2')
engine.addEntity(signpostTree2)
signpostTree2.setParent(_scene)
const transform64 = new Transform({
  position: new Vector3(11.991195678710938, 18.5, 14.63577651977539),
  rotation: new Quaternion(0.6766590476036072, 0.6766589879989624, -0.20526236295700073, -0.2052622139453888),
  scale: new Vector3(1.0000025033950806, 0.7418164610862732, 0.6857579946517944)
})
signpostTree2.addComponentOrReplace(transform64)

const ringWhiteLight = new Entity('ringWhiteLight')
engine.addEntity(ringWhiteLight)
ringWhiteLight.setParent(_scene)
const transform65 = new Transform({
  position: new Vector3(8.000000953674316, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringWhiteLight.addComponentOrReplace(transform65)
const gltfShape4 = new GLTFShape("0ce3c5ab4ebd2c3c6c33ec979ada6edb7f45313200399fbbe7778335d446b5b4/Ring_White_Light.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
ringWhiteLight.addComponentOrReplace(gltfShape4)

const ringWhiteLight5 = new Entity('ringWhiteLight5')
engine.addEntity(ringWhiteLight5)
ringWhiteLight5.setParent(_scene)
ringWhiteLight5.addComponentOrReplace(gltfShape4)
const transform66 = new Transform({
  position: new Vector3(8.000000953674316, 14.70341682434082, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringWhiteLight5.addComponentOrReplace(transform66)

const ringWhiteLight9 = new Entity('ringWhiteLight9')
engine.addEntity(ringWhiteLight9)
ringWhiteLight9.setParent(_scene)
ringWhiteLight9.addComponentOrReplace(gltfShape4)
const transform67 = new Transform({
  position: new Vector3(8.000000953674316, 1.3819708824157715, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 140, 1)
})
ringWhiteLight9.addComponentOrReplace(transform67)

const ringWhiteLight2 = new Entity('ringWhiteLight2')
engine.addEntity(ringWhiteLight2)
ringWhiteLight2.setParent(_scene)
ringWhiteLight2.addComponentOrReplace(gltfShape4)
const transform68 = new Transform({
  position: new Vector3(8.000000953674316, 19.90748405456543, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.988813400268555, 0.20491035282611847, 7.988813400268555)
})
ringWhiteLight2.addComponentOrReplace(transform68)

const ringWhiteLight3 = new Entity('ringWhiteLight3')
engine.addEntity(ringWhiteLight3)
ringWhiteLight3.setParent(_scene)
ringWhiteLight3.addComponentOrReplace(gltfShape4)
const transform69 = new Transform({
  position: new Vector3(8.000000953674316, 17.063129425048828, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.988813400268555, 0.3986665606498718, 7.988813400268555)
})
ringWhiteLight3.addComponentOrReplace(transform69)

const sofaBlack = new Entity('sofaBlack')
engine.addEntity(sofaBlack)
sofaBlack.setParent(_scene)
const transform70 = new Transform({
  position: new Vector3(9.530407905578613, 17, 10.50644302368164),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
sofaBlack.addComponentOrReplace(transform70)
const gltfShape5 = new GLTFShape("a568ec89d5b55aae635d21ed9081d5db5793f8a4d006df02c7644f4a8863a79c/Sofa_Black.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
sofaBlack.addComponentOrReplace(gltfShape5)

const sofaBlack2 = new Entity('sofaBlack2')
engine.addEntity(sofaBlack2)
sofaBlack2.setParent(_scene)
sofaBlack2.addComponentOrReplace(gltfShape5)
const transform71 = new Transform({
  position: new Vector3(6.530407905578613, 17, 5.506443023681641),
  rotation: new Quaternion(5.538691796767522e-16, -1, 1.1920926823449918e-7, 0),
  scale: new Vector3(1, 1, 1)
})
sofaBlack2.addComponentOrReplace(transform71)

const sofaBlack3 = new Entity('sofaBlack3')
engine.addEntity(sofaBlack3)
sofaBlack3.setParent(_scene)
sofaBlack3.addComponentOrReplace(gltfShape5)
const transform72 = new Transform({
  position: new Vector3(11.030407905578613, 17, 6.506443023681641),
  rotation: new Quaternion(7.497071675488867e-15, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(1.0000007152557373, 1, 1.0000007152557373)
})
sofaBlack3.addComponentOrReplace(transform72)

const coffeeTable = new Entity('coffeeTable')
engine.addEntity(coffeeTable)
coffeeTable.setParent(_scene)
const transform73 = new Transform({
  position: new Vector3(8.052237510681152, 17, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6627728939056396, 1, 0.5527033805847168)
})
coffeeTable.addComponentOrReplace(transform73)
const gltfShape6 = new GLTFShape("c80d6609e7808171cdf1547900bf1a9ff87a102f4860d580b066aab37751483f/Coffee_Table.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
coffeeTable.addComponentOrReplace(gltfShape6)

const coffeeTable2 = new Entity('coffeeTable2')
engine.addEntity(coffeeTable2)
coffeeTable2.setParent(_scene)
coffeeTable2.addComponentOrReplace(gltfShape6)
const transform74 = new Transform({
  position: new Vector3(8.052237510681152, 17, 4.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6627728939056396, 1, 0.5527033805847168)
})
coffeeTable2.addComponentOrReplace(transform74)

const coffeeTable3 = new Entity('coffeeTable3')
engine.addEntity(coffeeTable3)
coffeeTable3.setParent(_scene)
coffeeTable3.addComponentOrReplace(gltfShape6)
const transform75 = new Transform({
  position: new Vector3(12.052237510681152, 17, 8),
  rotation: new Quaternion(1.1038385137852273e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1.6627728939056396, 1, 0.5527033805847168)
})
coffeeTable3.addComponentOrReplace(transform75)

const coffeeTable4 = new Entity('coffeeTable4')
engine.addEntity(coffeeTable4)
coffeeTable4.setParent(_scene)
coffeeTable4.addComponentOrReplace(gltfShape6)
const transform76 = new Transform({
  position: new Vector3(4.030407905578613, 17, 8.00644302368164),
  rotation: new Quaternion(-4.011840264563169e-15, -0.7071067690849304, 8.429367426288081e-8, 0.7071068286895752),
  scale: new Vector3(1.6627728939056396, 1, 0.5527033805847168)
})
coffeeTable4.addComponentOrReplace(transform76)

const sofaBlack4 = new Entity('sofaBlack4')
engine.addEntity(sofaBlack4)
sofaBlack4.setParent(_scene)
sofaBlack4.addComponentOrReplace(gltfShape5)
const transform77 = new Transform({
  position: new Vector3(5.052237510681152, 17, 9.5),
  rotation: new Quaternion(4.011840688079643e-15, 0.7071068286895752, -8.429367426288081e-8, -0.7071068286895752),
  scale: new Vector3(1.0000014305114746, 1, 1.0000014305114746)
})
sofaBlack4.addComponentOrReplace(transform77)

const radio = new Entity('radio')
engine.addEntity(radio)
radio.setParent(_scene)
const transform78 = new Transform({
  position: new Vector3(8, 17.476730346679688, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.7951841354370117, 1, 0.7515406608581543)
})
radio.addComponentOrReplace(transform78)

const invisibleWall = new Entity('invisibleWall')
engine.addEntity(invisibleWall)
invisibleWall.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(7.622720718383789, 17.263273239135742, 14.97259521484375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.437997341156006, -0.045621804893016815, 1.1262202262878418)
})
invisibleWall.addComponentOrReplace(transform79)

const invisibleWall2 = new Entity('invisibleWall2')
engine.addEntity(invisibleWall2)
invisibleWall2.setParent(_scene)
const transform80 = new Transform({
  position: new Vector3(8, 17.263273239135742, 0.97259521484375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.362231731414795, -0.045621804893016815, 1.1262202262878418)
})
invisibleWall2.addComponentOrReplace(transform80)

const invisibleWall3 = new Entity('invisibleWall3')
engine.addEntity(invisibleWall3)
invisibleWall3.setParent(_scene)
const transform81 = new Transform({
  position: new Vector3(0.9999997615814209, 17.263273239135742, 8.97259521484375),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.3622355461120605, -0.045621804893016815, 1.126220703125)
})
invisibleWall3.addComponentOrReplace(transform81)

const invisibleWall4 = new Entity('invisibleWall4')
engine.addEntity(invisibleWall4)
invisibleWall4.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(14.951900482177734, 17.263273239135742, 8.206197738647461),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.362243175506592, -0.045621804893016815, 1.1262216567993164)
})
invisibleWall4.addComponentOrReplace(transform82)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape7 = new GLTFShape("bfc932843fa883cacaa9d8ffd5fc94069b36c6facc8756ee4768097f7545c2c4/CityTile.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
entity.addComponentOrReplace(gltfShape7)
const transform83 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform83)

const externalLink = new Entity('externalLink')
engine.addEntity(externalLink)
externalLink.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
externalLink.addComponentOrReplace(transform84)

const imageFromURL = new Entity('imageFromURL')
engine.addEntity(imageFromURL)
imageFromURL.setParent(_scene)
const transform85 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
imageFromURL.addComponentOrReplace(transform85)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
const script7 = new Script7()
const script8 = new Script8()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script7.init(options)
script8.init(options)
script1.spawn(verticalBlackPad, {"distance":17,"speed":5,"autoStart":false,"onReachEnd":[],"onReachStart":[]}, createChannel(channelId, verticalBlackPad, channelBus))
script2.spawn(nftPictureFrame, {"id":"72405646120007613708465591283795435405784754144165659770746301224007793377281","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame, channelBus))
script2.spawn(nftPictureFrame2, {"id":"72405646120007613708465591283795435405784754144165659770746301207515118960641","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame2, channelBus))
script2.spawn(nftPictureFrame5, {"id":"72405646120007613708465591283795435405784754144165659770746301233903398027265","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .24 ETH"}, createChannel(channelId, nftPictureFrame5, channelBus))
script2.spawn(nftPictureFrame6, {"id":"72405646120007613708465591283795435405784754144165659770746301227306328260609","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame6, channelBus))
script2.spawn(nftPictureFrame9, {"id":"72405646120007613708465591283795435405784754144165659770746301241599979421697","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .24 ETH"}, createChannel(channelId, nftPictureFrame9, channelBus))
script2.spawn(nftPictureFrame10, {"id":"72405646120007613708465591283795435405784754144165659770746301232803886399489","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame10, channelBus))
script2.spawn(nftPictureFrame13, {"id":"72405646120007613708465591283795435405784754144165659770746301236102421282817","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .24 ETH"}, createChannel(channelId, nftPictureFrame13, channelBus))
script2.spawn(nftPictureFrame14, {"id":"72405646120007613708465591283795435405784754144165659770746301206415607332865","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame14, channelBus))
script2.spawn(nftPictureFrame17, {"id":"72405646120007613708465591283795435405784754144165659770746301188823421288449","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .24 ETH"}, createChannel(channelId, nftPictureFrame17, channelBus))
script2.spawn(nftPictureFrame18, {"id":"72405646120007613708465591283795435405784754144165659770746301217410723610625","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame18, channelBus))
script2.spawn(nftPictureFrame21, {"id":"72405646120007613708465591283795435405784754144165659770746301242699491049473","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame21, channelBus))
script2.spawn(nftPictureFrame22, {"id":"72405646120007613708465591283795435405784754144165659770746301196520002682881","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame22, channelBus))
script2.spawn(nftPictureFrame25, {"id":"72405646120007613708465591283795435405784754144165659770746301115156142227457","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame25, channelBus))
script2.spawn(nftPictureFrame26, {"id":"72405646120007613708465591283795435405784754144165659770746301191022444544001","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame26, channelBus))
script2.spawn(nftPictureFrame29, {"id":"72405646120007613708465591283795435405784754144165659770746301213012677099521","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame29, channelBus))
script2.spawn(nftPictureFrame30, {"id":"72405646120007613708465591283795435405784754144165659770746301200918049193985","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .16 ETH"}, createChannel(channelId, nftPictureFrame30, channelBus))
script3.spawn(triggerArea, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}]}, createChannel(channelId, triggerArea, channelBus))
script4.spawn(signpostTree2, {"text":"EXIT","fontSize":40}, createChannel(channelId, signpostTree2, channelBus))
script5.spawn(radio, {"startOn":true,"volume":1,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/QmahtwwASVk7oKaRz69dsDZCFFMY2JEEwE9M41xr4xbumo"}, createChannel(channelId, radio, channelBus))
script6.spawn(invisibleWall, {"enabled":true}, createChannel(channelId, invisibleWall, channelBus))
script6.spawn(invisibleWall2, {"enabled":true}, createChannel(channelId, invisibleWall2, channelBus))
script6.spawn(invisibleWall3, {"enabled":true}, createChannel(channelId, invisibleWall3, channelBus))
script6.spawn(invisibleWall4, {"enabled":true}, createChannel(channelId, invisibleWall4, channelBus))
script7.spawn(externalLink, {"url":"decentraland.org"}, createChannel(channelId, externalLink, channelBus))
script8.spawn(imageFromURL, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageFromURL, channelBus))